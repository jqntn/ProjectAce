# Petit projet de test

Pour intégrer ceci dans votre projet, copiez le dossier ENet6 dans votre dossier Source et rajoutez le module `ENet6Library` dans votre .Build.cs

Le `UENet6NetworkSubsystem` est automatiquement créé par le moteur et gère le réseau, n'hésitez pas à le modifier comme bon vous semble.